<?php

    return [
        'built_n_managing_by' => 'Built & being managed by',
        'welcome_user_with_role' => 'Welcome {{user}}, You entered with {{role}} role',
    ];