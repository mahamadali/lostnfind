<?php

namespace Models;

use Models\Base\Model;

class Faq extends Model
{
    protected $table = 'faq';
}