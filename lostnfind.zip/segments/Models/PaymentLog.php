<?php

namespace Models;

use Models\Base\Model;

class PaymentLog extends Model
{
    protected $table = 'payment_logs';
}