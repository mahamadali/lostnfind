<?php

namespace Models;

use Models\Base\Model;

class NotifyItem extends Model
{
    protected $table = 'notify_item';
}