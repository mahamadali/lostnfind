<?php

namespace Models;

use Models\Base\Model;

class RenewalMailSetting extends Model
{
	protected $table = 'renewal_mail_setting';

}