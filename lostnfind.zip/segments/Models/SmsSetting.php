<?php

namespace Models;

use Models\Base\Model;

class SmsSetting extends Model
{
	protected $table = 'sms_settings';

}