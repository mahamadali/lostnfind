<?php

namespace Models;

use Models\Base\Model;

class Company extends Model
{
	protected $table = 'companies';

}