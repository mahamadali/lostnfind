<?php

namespace Models;

use Models\Base\Model;

class MessageSetting extends Model
{
	protected $table = 'message_setting';

}