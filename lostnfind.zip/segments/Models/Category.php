<?php

namespace Models;

use Models\Base\Model;

class Category extends Model
{
	protected $table = 'categories';

}