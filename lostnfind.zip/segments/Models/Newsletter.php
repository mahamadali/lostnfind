<?php

namespace Models;

use Models\Base\Model;

class Newsletter extends Model
{
	protected $table = 'newsletter';

}