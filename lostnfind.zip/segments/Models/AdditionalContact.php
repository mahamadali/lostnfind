<?php

namespace Models;

use Models\Base\Model;

class AdditionalContact extends Model
{
	protected $table = 'additional_contacts';

}