<?php

namespace Models;

use Models\Base\Model;

class Role extends Model
{
	protected $table = 'roles';

}