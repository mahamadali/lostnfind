<?php

namespace Controllers;

class WelcomeController
{
    public function index()
    {
        return render('welcome');
    }
}