<html>
    <head>
        <title>@plot('title')</title>
        <meta charset="utf-8">
        @plot('styles')
    </head>
    <body>
        @plot('content')
        @plot('scripts')
    </body>
</html>