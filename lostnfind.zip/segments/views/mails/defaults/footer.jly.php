													<table class="paragraph_block block-6" width="100%" border="0" cellpadding="0" cellspacing="0" role="presentation" style="mso-table-lspace: 0pt; mso-table-rspace: 0pt; word-break: break-word;">
														<tr>
															<td class="pad" style="padding-top:15px;">
																<div style="color:#88888d;font-size:12px;font-family:Arial, Helvetica Neue, Helvetica, sans-serif;font-weight:400;line-height:120%;text-align:center;direction:ltr;letter-spacing:0px;mso-line-height-alt:14.399999999999999px;">
																	<p style="margin: 0; padding: 2px;">All copyrights reserved {{ date('Y') }}.</p>
																	<p style="margin: 0; padding: 2px;">Sent via {{ setting('app.title') }}</p>
																</div>
															</td>
														</tr>
													</table>
													</td>
													</tr>
													</tbody>
													</table>
													</td>
													</tr>
													</tbody>
													</table>
													</td>
													</tr>
													</tbody>
													</table><!-- End -->
													</body>

													</html>